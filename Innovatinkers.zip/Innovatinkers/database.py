from flask import Flask, jsonify, request, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__, static_folder='static')

CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///dummy_database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class BusSchedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bus_number = db.Column(db.String(100), nullable=False)
    from_location = db.Column(db.String(100), nullable=False)
    to_location = db.Column(db.String(100), nullable=False)
    arrival_time = db.Column(db.String(100), nullable=False)
    departure_time = db.Column(db.String(100), nullable=False)

@app.route("/init_db")
def init_db():
    db.create_all()
    dummy_data = [

        BusSchedule(bus_number="KSRTC101", from_location="Trivandrum", to_location="Kochi", arrival_time="08:00 AM", departure_time="08:15 AM"),
        BusSchedule(bus_number="KSRTC102", from_location="Kochi", to_location="Calicut", arrival_time="09:00 AM", departure_time="09:15 AM"),
        BusSchedule(bus_number="KSRTC103", from_location="Calicut", to_location="Kannur", arrival_time="10:00 AM", departure_time="10:15 AM"),
        BusSchedule(bus_number="KSRTC104", from_location="Trivandrum", to_location="Calicut", arrival_time="11:00 AM", departure_time="11:15 AM"),
        BusSchedule(bus_number="KSRTC105", from_location="Kochi", to_location="Trivandrum", arrival_time="12:00 PM", departure_time="12:15 PM")
    ]
    db.session.bulk_save_objects(dummy_data)
    db.session.commit()
    return jsonify({"message": "Database initialized with dummy data"})

@app.route("/search")
def search():
    from_location = request.args.get('from')
    to_location = request.args.get('to')

    if not from_location or not to_location:
        return jsonify({"error": "Please provide both 'from' and 'to' locations"}), 400

    schedules = BusSchedule.query.filter_by(from_location=from_location, to_location=to_location).all()

    if not schedules:
        return jsonify({"message": "No bus schedules found for the given locations"}), 404

    result = [
        {
            "bus_number": schedule.bus_number,
            "from_location": schedule.from_location,
            "to_location": schedule.to_location,
            "arrival_time": schedule.arrival_time,
            "departure_time": schedule.departure_time
        } for schedule in schedules
    ]

    return jsonify(result)

@app.route("/get_schedules")
def get_schedules():
    schedules = BusSchedule.query.all()
    result = [
        {
            "bus_number": schedule.bus_number,
            "from_location": schedule.from_location,
            "to_location": schedule.to_location,
            "arrival_time": schedule.arrival_time,
            "departure_time": schedule.departure_time
        } for schedule in schedules
    ]
    return jsonify(result)

@app.route("/")
def home():
    return render_template("index.html")

@app.route('/bus_or_uber')
def bus_uber():
    return render_template('next.html')

@app.route('/bus')
def bus():
    return render_template('bus.html')

@app.route('/uber')
def uber():
    return render_template('uber.html')

@app.route('/bus_result')
def bus_result():
    from_location = request.args.get('from')
    to_location = request.args.get('to')

    if not from_location or not to_location:
        return jsonify({"error": "Please provide both 'from' and 'to' locations"}), 400

    schedules = BusSchedule.query.filter_by(from_location=from_location, to_location=to_location).all()

    if not schedules:
        return jsonify({"message": "No bus schedules found for the given locations"}), 404

    html = "<p>"

    #[{name:krishna}, {name:afreedi},...]
    for schedule in schedules:
        html = html + "<h1>"+schedule.bus_number+", "+schedule.from_location+", "+schedule.arrival_time+", "+schedule.departure_time+"</h1>"

    html = html + "</p>"

    return html


if __name__ == "__main__":
    app.run(debug=True)


